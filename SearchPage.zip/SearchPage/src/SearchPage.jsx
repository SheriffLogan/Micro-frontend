import React from 'react'

function SearchPage() {

    // const user = props.userdata;
  return (
    <div>
ascjas mc

    </div>
  )
}

export default SearchPage
