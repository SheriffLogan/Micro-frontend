import React from "react";
import ReactDOM from "react-dom";
import {BrowserRouter as Router,Route,Routes}from 'react-router-dom';
import { LoginComponent } from "Login/LoginComponent";

// import "./index.css";
import { RegisterComponent } from "./RegisterComponent";






const App = () => (
  <div className="container">
    {/* <RegisterComponent/> */}
    <Router>

{/* <Navbar/>

<Sidebar/> */}

<Routes>

  <Route exact path ="/" element= {<RegisterComponent/>}></Route>

  <Route exact path = "/Login" element= {<LoginComponent/>}></Route>

  {/* <Route exact path = "/Login"><Login/></Route> */}

</Routes>

</Router>
  </div>
);
ReactDOM.render(<App />, document.getElementById("app"));
