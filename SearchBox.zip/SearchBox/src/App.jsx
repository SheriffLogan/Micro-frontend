import React from "react";
import ReactDOM from "react-dom";

// import "./App.css";
import SearchBox2 from "./SearchBox2";

const App = () => (
 <div>
  <SearchBox2/>
 </div>
);
ReactDOM.render(<App />, document.getElementById("app"));
